
# S0 Empirical Strategy

## Objective

Reconstruct the data environment necessary to replicate Shaikh’s capacity utilization measure.

The key empirical relation is:

ln(Y) − θ ln(K) = ln(u)

where:

Y = output  
K = capital stock  
u = capacity utilization

## Identification Logic

S0 does not estimate models. Instead it reconstructs the **objects required for estimation**:

- Output series
- Capital stock series
- Common deflator
- Profit share and exploitation variables

These objects define the accounting environment used in later econometric stages.

## Estimation Pipeline

1. Import raw dataset
2. Deflate nominal series
3. Construct real output and capital stock
4. Compute utilization proxy
5. Export canonical dataset

## Admissibility Rules

The data reconstruction stage enforces:

- consistent deflator application
- consistent sector definitions
- alignment with Shaikh’s published dataset

## Geometry

Although no estimation occurs, S0 defines the data objects used later in the fit–complexity geometry used in S1 and S2.
