
# S0 — Data Reconstruction & Faithful Replication

## Purpose
Stage S0 reconstructs the data environment required to reproduce Shaikh’s original capacity utilization estimates. 
It ensures that the raw series, transformations, and accounting identities are faithfully aligned with the objects used in the original empirical implementation.

## Role in the Replication Pipeline
S0 → S1 → S2

- **S0**: Data fidelity and reconstruction.
- **S1**: ARDL specification lattice and single‑equation cointegration geometry.
- **S2**: System estimation (VECM) and confinement geometry in higher dimension.

S0 therefore provides the **data contract** used by all subsequent stages.

## Workflow Overview

1. Import raw series
2. Construct nominal and real variables
3. Verify accounting identities
4. Replicate Shaikh baseline utilization series
5. Export canonical dataset for S1 and S2

## Outputs

- Replicated utilization series
- Verified dataset used in ARDL and VECM stages
