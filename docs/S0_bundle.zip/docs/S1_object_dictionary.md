
# S1 Object Dictionary

Specification grammar:

Spec = {p, q, c, s}

p
    Lag depth of the dependent variable.

q
    Lag depth of the regressor.

c
    Deterministic specification case (1–5).

s
    Shaikh deterministic toggle.

Derived quantities:

k_total
    Total parameter count.

logLik
    Model log‑likelihood.

IC
    Information criterion value.
