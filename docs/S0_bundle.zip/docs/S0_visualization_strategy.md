
# S0 Visualization Strategy

Stage S0 focuses on **replication validation plots**.

## Figure S0.1 — Output and Capital Series

Time series plot showing:

- ln(Y)
- ln(K)

Purpose:
Verify long-run comovement.

## Figure S0.2 — Replicated Utilization

Comparison plot:

- Shaikh published utilization
- Replicated utilization

Purpose:
Validate data reconstruction.

Visualization tools:

- ggplot2 line plots
- facetting where necessary
