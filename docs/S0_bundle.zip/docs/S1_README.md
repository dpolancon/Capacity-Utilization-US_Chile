
# S1 — ARDL Specification Lattice

## Purpose

Stage S1 explores the ARDL specification lattice used to estimate the long‑run relation between output and capital.

It evaluates how different ARDL structures affect the identification of productive capacity.

## Role in the Replication Pipeline

S0 → S1 → S2

- S0 constructs the dataset.
- **S1 evaluates single‑equation cointegration models.**
- S2 estimates the system representation (VECM).

## Workflow Overview

1. Estimate ARDL models across the lattice.
2. Apply bounds testing to determine admissibility.
3. Compute information criteria.
4. Map models in the fit–complexity plane.
