
# S0 Object Dictionary

Specification grammar for Stage S0:

Spec = {dataset, deflator, transformation}

Where:

dataset  
    Raw data source used to construct the empirical series.

deflator  
    Price index used to convert nominal magnitudes into real terms.

transformation  
    Functional transformations applied to variables (log, growth rate, etc.).

Primary Variables

Y  
    Real output.

K  
    Real capital stock.

u  
    Capacity utilization proxy.

π  
    Profit share.

e  
    Rate of exploitation.
