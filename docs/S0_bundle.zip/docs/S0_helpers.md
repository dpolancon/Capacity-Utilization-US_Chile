
# S0 Helpers

## Data Import Helpers

load_shaikh_data()
    Reads raw Excel dataset and standardizes column names.

## Transformation Helpers

deflate_series()
    Applies chosen price index to nominal variables.

log_transform()
    Converts variables into natural logarithms.

## Validation Helpers

compare_series()
    Compares reconstructed series with published reference series.
