
# S1 Visualization Strategy

Figures follow the fit–complexity geometry.

## Figure S1.1 — Global Frontier

Scatter plot:

X-axis = complexity (k_total)  
Y-axis = −2 logLik

Frontier identifies best‑fit model at each complexity.

## Figure S1.2 — Information Criterion Tangencies

Overlay decision rules:

- AIC
- BIC
- HQ
- ICOMP
- RICOMP

## Figure S1.3 — Informational Domain

Highlight models within the informational frontier region.
