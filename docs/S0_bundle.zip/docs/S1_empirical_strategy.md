
# S1 Empirical Strategy

## Model Structure

ARDL model relating output and capital:

ln(Y_t) = θ ln(K_t) + ε_t

where ε_t represents utilization dynamics.

## Specification Lattice

Spec = {p, q, c, s}

p = lag order of Y  
q = lag order of K  
c = deterministic case (ARDL cases 1–5)  
s = Shaikh dummy toggle

## Admissibility

A model enters the admissible set if the bounds F‑test rejects the null of no cointegration.

## Model Comparison Geometry

Models are compared using:

X-axis: complexity (k_total)  
Y-axis: −2 logLik

Information criteria:

IC = −2 logLik + λ·k_total

The frontier of this geometry identifies efficient ARDL models.
