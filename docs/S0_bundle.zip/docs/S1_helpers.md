
# S1 Helpers

estimate_ardl()
    Wrapper around ARDL estimation routine.

bounds_test()
    Computes bounds F‑test statistics.

extract_loglik()
    Retrieves model log‑likelihood.

count_parameters()
    Calculates model complexity k_total.

compute_ic()
    Calculates information criteria values.
