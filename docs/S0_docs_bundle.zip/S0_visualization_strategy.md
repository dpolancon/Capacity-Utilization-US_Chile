# Stage S0 — Visualization Strategy

Stage S0 visualizations focus on verifying the empirical object produced by the replication.

All plots remain compatible with the fit–complexity representation used in later stages.

X-axis = model complexity (k_total)  
Y-axis = −2 logLik

---

## Figure 1 — Utilization Replication Plot

Time-series comparison between

• published Shaikh utilization series  
• replicated utilization series

---

## Figure 2 — Capacity Benchmark Plot

Comparison between

• observed output  
• estimated productive capacity

---

## Figure 3 — Error-Correction Diagnostics

Visualization of error-correction residuals and adjustment dynamics.

---

## Figure 4 — Model Position in Fit–Complexity Space

Even though Stage S0 uses a fixed specification, the model is placed within the fit–complexity geometry to ensure comparability with Stage S1 frontier analysis.