# Stage S0 — Faithful Replication Layer

## Purpose

Stage S0 reconstructs the empirical object reported in Shaikh’s measurement of capacity utilization using a fixed ARDL specification.

The objective is to reproduce the utilization series implied by the original ARDL framework before any model-selection or system estimation procedures are introduced.

Stage S0 therefore establishes the **baseline empirical object** used throughout the replication pipeline.

---

## Conceptual Role in the Replication Pipeline

The replication architecture consists of three stages:

| Stage | Object | Method |
|------|------|------|
| S0 | Faithful Shaikh replication | Fixed ARDL |
| S1 | Specification geometry | ARDL IC contest |
| S2 | Structural identification | VECM system |

S0 reconstructs the original empirical series and its econometric identification logic.

S1 evaluates the robustness of that identification across the ARDL specification space.

S2 re-estimates the relation within a system cointegration framework.

---

## Workflow Overview

The Stage S0 workflow proceeds as follows:

1. Load replication dataset and construct real series.
2. Build ARDL(2,4) specification used in the original study.
3. Estimate the ARDL model under the deterministic case used in the benchmark.
4. Recover the long-run productive-capacity relation.
5. Construct the utilization series implied by the estimated capacity benchmark.
6. Compare the reconstructed utilization with the published Shaikh series.

---

## Outputs

Stage S0 produces:

• replication time-series comparison plots  
• ARDL coefficient tables  
• bounds-test diagnostics  
• utilization reconstruction tables

These outputs verify that the baseline empirical object has been reproduced correctly before moving to specification exploration.