# Stage S0 — Empirical Strategy

## Objective

Stage S0 reconstructs the empirical identification of productive capacity implied by Shaikh’s ARDL framework.

The strategy is to estimate the fixed ARDL specification used in the original study and recover the implied productive-capacity benchmark.

---

## Model Structure

The ARDL representation is

ln Y_t = α + Σ φ_i ln Y_{t−i} + Σ β_j ln K_{t−j} + deterministic terms + ε_t

The long-run productive-capacity relation is defined as

ln Y_t^p = θ ln K_t + deterministic multipliers

Capacity utilization is recovered as

u_t = Y_t / Y_t^p

---

## Identification Logic

The long-run relation identifies the transformation from capital stock to productive capacity.

The parameter

θ = ∂ ln Y^p / ∂ ln K

measures the elasticity of productive capacity with respect to capital stock.

The speed-of-adjustment parameter α captures error-correction dynamics toward the capacity benchmark.

---

## Estimation Pipeline

1. Construct real output and capital series using a common deflator.
2. Estimate ARDL(p,q) specification fixed at the benchmark lag structure.
3. Extract long-run multipliers.
4. Construct productive-capacity series.
5. Compute utilization series.

---

## Admissibility Rules

The estimated ARDL model must:

• converge numerically  
• produce a valid error-correction representation  
• pass the bounds F test for cointegration.

Bounds t test results are recorded as a robustness check.

---

## Model Comparison Geometry

Even though Stage S0 focuses on a fixed specification, it remains embedded within the same geometry used in later stages.

Each model can be represented by

Fit = −2 logLik  
Complexity = k_total

Information criteria follow

IC = −2 logLik + λ·k_total

This representation ensures consistency with the frontier analysis implemented in Stage S1 and Stage S2.