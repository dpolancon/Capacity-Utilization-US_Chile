# Stage S0 — Object Dictionary

## Specification Grammar

Stage S0 specifications are indexed by

Spec = {dataset, deflator, ardl}

---

### dataset — Source Dataset

Dataset used for replication.

Example:

dataset = Shaikh_RepData

---

### deflator — Price Index

Common price index used to construct real output and capital.

Example:

deflator = Py

---

### ardl — ARDL Specification

Fixed lag structure used for replication.

Example

ardl = (p=2, q=4)

---

### θ — Capacity Elasticity

Long-run elasticity of productive capacity with respect to capital stock.

---

### α — Speed of Adjustment

Error-correction coefficient governing convergence toward the long-run capacity relation.

---

### k_total — Model Complexity

Total number of estimated parameters.

---

### −2 logLik — Model Fit

Negative twice the log-likelihood of the ARDL model.