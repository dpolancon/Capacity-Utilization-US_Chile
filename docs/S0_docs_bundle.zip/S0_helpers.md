# Stage S0 — Helper Functions

Stage S0 relies on helper utilities that standardize the replication workflow.

---

## load_replication_data()

Loads the replication dataset and constructs real variables.

Responsibilities:

• read raw dataset  
• construct real output and capital  
• apply common deflator

---

## run_shaikh_ardl()

Wrapper function estimating the benchmark ARDL specification.

Responsibilities:

• construct ARDL formula  
• estimate model  
• return fitted object

---

## extract_long_run_multipliers()

Extracts long-run coefficients from the ARDL object.

Returns

• θ elasticity  
• deterministic multipliers

---

## compute_utilization()

Constructs utilization series

u_t = Y_t / Y_t^p

---

## extract_bounds_tests()

Extracts bounds F and t tests from the ARDL model.

---

## extract_logLik()

Computes −2 logLik from the estimated model.

---

## count_parameters()

Counts k_total parameters of the specification.